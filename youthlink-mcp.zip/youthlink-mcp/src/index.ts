import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';
import { google } from 'googleapis';
import express from 'express';

// ============================================
// 設定
// ============================================
const SPREADSHEET_ID = '1apDuNqifsWD0IkWHAPpO31hWbVkoMSUc997NRVqcy0Y';

// 月名マッピング（シートの表記ゆれに対応）
const MONTH_PREFIX: Record<number, string> = {
  1: '1', 2: '2', 3: '3', 4: '４', 5: '5', 6: '6',
  7: '7', 8: '8', 9: '9', 10: '10', 11: '11', 12: '12'
};

// 案件タイプ自動判定ルール
const TYPE_RULES: [string, string][] = [
  ['ジョブハント', 'GP'], ['DYM', 'GP'], ['シンアド', 'GP'],
  ['GRIT', 'GP'], ['ワンキャリア', 'GP'], ['ワンキャリ', 'GP'],
  ['チアキャリ', 'GP'], ['ルビーイン', 'GP'], ['ウェルハンティング', 'GP'],
  ['FC)', '面談'], ['Ai)', '面談'], ['AI)', '面談'],
  ['ジール', '面談'], ['ジョーカツ', '面談'], ['UZUZ', '面談'],
  ['スターマイン', '面談'], ['正直エージェント', '面談'],
  ['イロダス', '面談'], ['HRteam', '面談'], ['0円就活', '面談'],
  ['アクセス', 'その他'], ['みん就', 'その他'], ['社長飯', 'その他'],
  ['キャリガク', 'その他'], ['Winc', 'その他'], ['Shabell', 'その他'],
  ['SRB', 'その他'], ['しゃべる', 'その他'], ['アスキャリ', 'その他'],
];

// ============================================
// Google Sheets認証
// ============================================
function getAuthClient() {
  const credentials = JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT_KEY || '{}');
  return new google.auth.GoogleAuth({
    credentials,
    scopes: ['https://www.googleapis.com/auth/spreadsheets'],
  });
}

async function getSheetsClient() {
  const auth = getAuthClient();
  return google.sheets({ version: 'v4', auth });
}

// ============================================
// ユーティリティ関数
// ============================================
function detectType(caseName: string): string {
  for (const [key, val] of TYPE_RULES) {
    if (caseName.includes(key)) return val;
  }
  return 'GP';
}

function parseDate(dateStr: string): { month: number; day: number; formatted: string } {
  const str = String(dateStr).trim();
  const now = new Date();
  const year = now.getFullYear();

  const md = str.match(/^(\d{1,2})[\/月](\d{1,2})/);
  if (md) {
    const month = parseInt(md[1]);
    const day = parseInt(md[2]);
    return { month, day, formatted: `${month}/${day}` };
  }

  const ymd = str.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})/);
  if (ymd) {
    const month = parseInt(ymd[2]);
    const day = parseInt(ymd[3]);
    return { month, day, formatted: `${month}/${day}` };
  }

  const d = new Date(str);
  return {
    month: d.getMonth() + 1,
    day: d.getDate(),
    formatted: `${d.getMonth() + 1}/${d.getDate()}`
  };
}

function buildSheetName(month: number, type: string, person: string): string {
  const m = MONTH_PREFIX[month] || String(month);
  return `${m}月（${type}）${person}`;
}

// ============================================
// シート操作関数
// ============================================
async function getSheetNames(): Promise<string[]> {
  const sheets = await getSheetsClient();
  const res = await sheets.spreadsheets.get({ spreadsheetId: SPREADSHEET_ID });
  return res.data.sheets?.map(s => s.properties?.title || '') || [];
}

async function readSheet(sheetName: string, range?: string): Promise<any[][]> {
  const sheets = await getSheetsClient();
  const fullRange = range ? `${sheetName}!${range}` : sheetName;
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId: SPREADSHEET_ID,
    range: fullRange,
  });
  return res.data.values || [];
}

async function appendRow(sheetName: string, rowData: any[]): Promise<{ row: number }> {
  const sheets = await getSheetsClient();

  // 既存データを取得して最終行を見つける
  const existing = await readSheet(sheetName);
  let lastDataRow = 0;
  for (let i = existing.length - 1; i >= 0; i--) {
    const row = existing[i];
    const hasContent = row.some((cell: any) =>
      cell !== '' && cell !== false && cell !== null && cell !== undefined && cell !== 'FALSE'
    );
    if (hasContent && row[0] !== '案件名' && row[0] !== '対面案件名') {
      lastDataRow = i + 1;
      break;
    }
  }

  const newRow = lastDataRow + 1;
  const range = `${sheetName}!A${newRow}`;

  await sheets.spreadsheets.values.update({
    spreadsheetId: SPREADSHEET_ID,
    range,
    valueInputOption: 'USER_ENTERED',
    requestBody: { values: [rowData] },
  });

  return { row: newRow };
}

async function updateCell(sheetName: string, cellRange: string, value: any): Promise<void> {
  const sheets = await getSheetsClient();
  await sheets.spreadsheets.values.update({
    spreadsheetId: SPREADSHEET_ID,
    range: `${sheetName}!${cellRange}`,
    valueInputOption: 'USER_ENTERED',
    requestBody: { values: [[value]] },
  });
}

// ============================================
// MCPサーバー定義
// ============================================
const server = new Server(
  { name: 'youthlink-sheets-mcp', version: '1.0.0' },
  { capabilities: { tools: {} } }
);

// ツール一覧
server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: 'add_booking',
      description: '学生の予約をスプレッドシートに追加する。イベント名・日付・学生名を受け取り、適切なシートタブに自動で記入する。',
      inputSchema: {
        type: 'object',
        properties: {
          案件名: { type: 'string', description: 'イベント名または案件名。例: ジョブハント, DYM FC, FC)ジール' },
          日付: { type: 'string', description: '日付。例: 6/10, 6月10日, 2026/06/10' },
          学生名: { type: 'string', description: '学生の氏名' },
          担当: { type: 'string', description: '担当者。齋藤 または 濱谷', enum: ['齋藤', '濱谷'], default: '齋藤' },
          案件タイプ: { type: 'string', description: 'GP / 面談 / その他。省略時は案件名から自動判定', enum: ['GP', '面談', 'その他'] },
          時間: { type: 'string', description: '時間区分。午前 / 午後 / 終日', enum: ['午前', '午後', '終日', ''] },
          経由: { type: 'string', description: '紹介者。例: 小林, 池田, 陽介' },
          受注額: { type: 'number', description: 'クライアントへの請求額（円）' },
          支払い額: { type: 'number', description: '学生への支払い額（円）' },
          備考: { type: 'string', description: '備考・メモ' },
        },
        required: ['案件名', '日付', '学生名'],
      },
    },
    {
      name: 'read_sheet',
      description: '指定したシートタブの内容を読み込む。今月のデータ確認・未払い確認などに使う。',
      inputSchema: {
        type: 'object',
        properties: {
          シート名: { type: 'string', description: 'シートタブ名。例: 5月（GP）齋藤, 年間収支' },
          範囲: { type: 'string', description: 'セル範囲。例: A1:L50。省略時はシート全体' },
        },
        required: ['シート名'],
      },
    },
    {
      name: 'list_sheets',
      description: 'スプレッドシートのシートタブ一覧を取得する。',
      inputSchema: { type: 'object', properties: {} },
    },
    {
      name: 'update_booking_status',
      description: '既存の予約行のステータスを更新する。着座・成果・支払い確認などを更新できる。',
      inputSchema: {
        type: 'object',
        properties: {
          シート名: { type: 'string', description: 'シートタブ名' },
          行番号: { type: 'number', description: '更新する行番号（1始まり）' },
          列: { type: 'string', description: '更新する列。着座/成果/支払い確認/受注額/支払い額/利益/備考' },
          値: { description: '新しい値' },
        },
        required: ['シート名', '行番号', '列', '値'],
      },
    },
    {
      name: 'search_student',
      description: '学生名で過去の送客記録を横断検索する。同じ学生が何回来ているか、どの案件に参加したかを確認できる。',
      inputSchema: {
        type: 'object',
        properties: {
          学生名: { type: 'string', description: '検索する学生名（部分一致）' },
        },
        required: ['学生名'],
      },
    },
    {
      name: 'get_monthly_summary',
      description: '指定月の送客サマリーを取得する。承認済み件数・売上・支払い額・利益を集計する。',
      inputSchema: {
        type: 'object',
        properties: {
          月: { type: 'number', description: '月（1〜12）' },
          担当: { type: 'string', description: '担当者。齋藤 / 濱谷 / 両方', enum: ['齋藤', '濱谷', '両方'], default: '両方' },
        },
        required: ['月'],
      },
    },
  ],
}));

// ツール実行
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {
    switch (name) {
      case 'add_booking': {
        const { 案件名, 日付, 学生名, 担当 = '齋藤', 案件タイプ, 時間 = '', 経由 = '', 受注額 = '', 支払い額 = '', 備考 = '' } = args as any;

        const dateInfo = parseDate(日付);
        const type = 案件タイプ || detectType(案件名);
        const sheetName = buildSheetName(dateInfo.month, type, 担当);

        // シートが存在するか確認
        const sheetNames = await getSheetNames();
        if (!sheetNames.includes(sheetName)) {
          return {
            content: [{
              type: 'text',
              text: `⚠️ シート「${sheetName}」が存在しません。\n利用可能なシート: ${sheetNames.filter(s => s.includes('月')).join(', ')}`
            }]
          };
        }

        // 利益計算
        const profit = (受注額 && 支払い額) ? Number(受注額) - Number(支払い額) : '';

        const rowData = [
          案件名,
          dateInfo.formatted,
          時間,
          学生名,
          受注額 ? Number(受注額) : '',
          支払い額 ? Number(支払い額) : '',
          profit,
          '',   // 着座
          '',   // 成果
          経由,
          'FALSE', // 支払い確認
          備考,
        ];

        const result = await appendRow(sheetName, rowData);

        return {
          content: [{
            type: 'text',
            text: `✅ 追加完了\n・シート: ${sheetName}\n・行: ${result.row}行目\n・案件: ${案件名}\n・日付: ${dateInfo.formatted}\n・学生: ${学生名}${経由 ? `\n・経由: ${経由}` : ''}${受注額 ? `\n・受注額: ¥${Number(受注額).toLocaleString()}` : ''}${支払い額 ? `\n・支払い: ¥${Number(支払い額).toLocaleString()}` : ''}`
          }]
        };
      }

      case 'read_sheet': {
        const { シート名, 範囲 } = args as any;
        const data = await readSheet(シート名, 範囲);

        if (data.length === 0) {
          return { content: [{ type: 'text', text: `「${シート名}」にデータがありません。` }] };
        }

        // テキスト形式で整形
        const formatted = data
          .filter(row => row.some((cell: any) => cell !== '' && cell !== false && cell !== 'FALSE'))
          .map((row, i) => `${i + 1}: ${row.join(' | ')}`)
          .join('\n');

        return { content: [{ type: 'text', text: `【${シート名}】\n${formatted}` }] };
      }

      case 'list_sheets': {
        const names = await getSheetNames();
        const monthly = names.filter(n => n.includes('月'));
        const other = names.filter(n => !n.includes('月'));
        return {
          content: [{
            type: 'text',
            text: `【月次シート】\n${monthly.join('\n')}\n\n【その他】\n${other.join('\n')}`
          }]
        };
      }

      case 'update_booking_status': {
        const { シート名, 行番号, 列, 値 } = args as any;
        const colMap: Record<string, string> = {
          '案件名': 'A', '日付': 'B', '時間': 'C', '学生名': 'D', '参加者氏名': 'D',
          '受注額': 'E', '支払い額': 'F', '利益': 'G',
          '着座': 'H', '成果': 'I', '経由': 'J',
          '支払い確認': 'K', '備考': 'L',
        };
        const col = colMap[列] || 列;
        await updateCell(シート名, `${col}${行番号}`, 値);
        return { content: [{ type: 'text', text: `✅ ${シート名} の ${行番号}行目「${列}」を「${値}」に更新しました。` }] };
      }

      case 'search_student': {
        const { 学生名 } = args as any;
        const sheetNames = await getSheetNames();
        const monthlySheets = sheetNames.filter(n => n.includes('月') && (n.includes('齋藤') || n.includes('濱谷')));

        const results: string[] = [];
        for (const sheetName of monthlySheets) {
          const data = await readSheet(sheetName);
          data.forEach((row, i) => {
            if (row[3] && String(row[3]).includes(学生名)) {
              results.push(`・${sheetName} / ${i + 1}行目 / ${row[0]} ${row[1]} / 受注:${row[4] || '-'} 支払:${row[5] || '-'} / 支払確認:${row[10]}`);
            }
          });
        }

        if (results.length === 0) {
          return { content: [{ type: 'text', text: `「${学生名}」の記録は見つかりませんでした。` }] };
        }

        return {
          content: [{
            type: 'text',
            text: `【${学生名} の送客記録 (${results.length}件)】\n${results.join('\n')}`
          }]
        };
      }

      case 'get_monthly_summary': {
        const { 月, 担当 = '両方' } = args as any;
        const sheetNames = await getSheetNames();

        const targets = sheetNames.filter(n => {
          const monthPrefix = MONTH_PREFIX[月];
          const hasMonth = n.startsWith(`${monthPrefix}月`);
          if (担当 === '両方') return hasMonth;
          return hasMonth && n.includes(担当);
        });

        let totalRevenue = 0, totalPay = 0, totalProfit = 0, count = 0;
        const byType: Record<string, { count: number; revenue: number; profit: number }> = {};

        for (const sheetName of targets) {
          const data = await readSheet(sheetName);
          const typeMatch = sheetName.match(/（(.+?)）/);
          const type = typeMatch ? typeMatch[1] : 'その他';

          data.forEach(row => {
            if (!row[0] || row[0] === '案件名' || row[0] === '対面案件名') return;
            if (!row[3]) return; // 学生名なし

            const revenue = Number(String(row[4]).replace(/[¥,]/g, '')) || 0;
            const pay = Number(String(row[5]).replace(/[¥,]/g, '')) || 0;
            const profit = Number(String(row[6]).replace(/[¥,]/g, '')) || (revenue - pay);

            totalRevenue += revenue;
            totalPay += pay;
            totalProfit += profit;
            count++;

            if (!byType[type]) byType[type] = { count: 0, revenue: 0, profit: 0 };
            byType[type].count++;
            byType[type].revenue += revenue;
            byType[type].profit += profit;
          });
        }

        const byTypeText = Object.entries(byType)
          .map(([t, v]) => `  ${t}: ${v.count}件 / 売上¥${v.revenue.toLocaleString()} / 利益¥${v.profit.toLocaleString()}`)
          .join('\n');

        return {
          content: [{
            type: 'text',
            text: `【${月}月 送客サマリー (${担当})】\n総件数: ${count}件\n総売上: ¥${totalRevenue.toLocaleString()}\n総支払: ¥${totalPay.toLocaleString()}\n総利益: ¥${totalProfit.toLocaleString()}\n\nタイプ別:\n${byTypeText}`
          }]
        };
      }

      default:
        return { content: [{ type: 'text', text: `不明なツール: ${name}` }] };
    }
  } catch (error: any) {
    return { content: [{ type: 'text', text: `❌ エラー: ${error.message}` }] };
  }
});

// ============================================
// HTTPサーバー（Railway用ヘルスチェック）
// ============================================
const app = express();
app.use(express.json());

app.get('/', (_req, res) => {
  res.json({ status: 'ok', name: 'YouthLink MCP Server', version: '1.0.0' });
});

app.get('/health', (_req, res) => {
  res.json({ status: 'healthy' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`YouthLink MCP Server running on port ${PORT}`);
});

// MCPサーバー起動
const transport = new StdioServerTransport();
server.connect(transport).catch(console.error);
